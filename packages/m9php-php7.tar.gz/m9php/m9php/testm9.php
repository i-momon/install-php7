<?php
	$str = "aaaa";
	echo "string befor encode:".$str."\n";
	$tmp = m9_encode($str);
	$len = strlen($tmp);
	echo "m9encode length:".$len."\n";

	$str2 =  m9_decode($tmp);
	echo "string after decode:".$str2."\n";
