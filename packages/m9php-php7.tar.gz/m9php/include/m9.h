#ifndef _UC_M9
#define _UC_M9
#ifdef __cplusplus
extern "C" {
#endif

/*
 * @return the size of str after encode by m9
 * */
int m9encode_size (const int _s_size);

/*
 * @return the size of str after decode by m9
 * */
int m9decode_size (const int _s_size);

/*
 * @return the size of str after encode by m8
 * */
int m8encode_size (const int _s_size);

/*
 * @return the size of str after decode by m8
 * */
 int m8decode_size (const int _s_size);

/*
 * @retcode :
 * 0 : succeeded
 * -2 : not enough buffer
 * -3 : invalid src
 * -4 : decode failed,not same mask
 * */
int m9_encode (const unsigned char* _src , const int _s_size , unsigned char* dest , int* d_size);

/*
 * @retcode :
 * 0 : succeeded
 * -2 : not enough buffer
 * */
int m8_encode(const unsigned char* _src , const int _s_size , unsigned char* dest, int* d_size);

/*
 * @retcode :
 * 0 : succeeded
 * -2 : not enough buffer
 * -3 : invalid src
 * -4 : decode failed,not same mask
 * */
int m9_decode (const unsigned char* _src , const int _s_size , unsigned char* dest , int* d_size);

/*
 * @retcode :
 * 0 : succeeded
 * -2 : not enough buffer
 * -3 : invalid src
 * -4 : decode failed,not same mask
 * */
int m8_decode(const unsigned char* _src ,  const int _s_size , unsigned char* dest , int* d_size);

/*
 * @retcode :
 * 0 : succeeded
 * -2 : not enough buffer
 * -3 : invalid src
 * -4 : decode failed,not same mask
 * */
int m9_encode_ltserver(const unsigned char* _src , const int _s_size , unsigned char* dest , int* d_size);


#ifdef __cplusplus
}
#endif
#endif /* _UC_M9 */













